"use strict";

function GraphConfigurationDialog(dialog, onSave) {
    var
        // Some fields it doesn't make sense to graph
        BLACKLISTED_FIELDS = {time:true, loopIteration:true},
        offeredFieldNames = [],
        exampleGraphs = [];
    
    function renderFieldOption(fieldName, selectedName) {
        var 
            option = $("<option></option>")
                .text(FlightLogFieldPresenter.fieldNameToFriendly(fieldName))
                .attr("value", fieldName);
    
        if (fieldName == selectedName) {
            option.attr("selected", "selected");
        }
        
        return option;
    }
    
    /**
     * Render the element for the "pick a field" dropdown box. Provide "field" from the config in order to set up the
     * initial selection.
     */
    function renderField(field) {
        //alert('rending field');
        var 
            elem = $(
                '<li class="config-graph-field">'
                    + '<select class="form-control"><option value="">(choose a field)</option></select>'
                    + '<button type="button" class="btn btn-default btn-sm">Remove</button>'
                + '</li>'
            ),
            select = $('select', elem),
            selectedFieldName = field ? field.name : false,
            i;
        
        for (i = 0; i < offeredFieldNames.length; i++) {
            select.append(renderFieldOption(offeredFieldNames[i], selectedFieldName));
        }
        
        return elem;
    }
    
    function renderGraph(index, graph) {
        console.log('Render Graph');
        var 
            graphElem = $(
                '<li class="config-graph">'
                    + '<dl>'
                        + '<dt><span>' 
                            + '<h4 style="display:inline-block;vertical-align: baseline;">Graph ' + '<span class="graph-index-number">' + (index + 1) + '</span>' + '</h4>' 
                            + '<button type="button" class="btn btn-default btn-sm pull-right remove-single-graph-button" style="display:inline-block;vertical-align: baseline;">Remove Graph ' + '</button>'    
                        + '</span></dt>'                     
                        + '<dd>'
                            + '<div class="form-horizontal">'
                                + '<div class="form-group">'
                                    + '<label class="col-sm-2 control-label">Axis label</label>'
                                    + '<div class="col-sm-10">'
                                        + '<input class="form-control" type="text" placeholder="Axis label">'
                                    + '</div>'
                                + '</div>'
                                + '<div class="form-group form-group-sm">'
                                    + '<label class="col-sm-2 control-label">Fields</label>'
                                    + '<div class="col-sm-10">'
                                        + '<ul class="config-graph-field-list form-inline list-unstyled"></ul>'
                                        + '<button type="button" class="btn btn-default btn-sm add-field-button"><span class="glyphicon glyphicon-plus"></span> Add field</button>'
                                    + '</div>'
                                + '</div>'
                            + '</div>'
                        + '</dd>'
                    + '</dl>'
                + '</li>'
            ),
            fieldList = $(".config-graph-field-list", graphElem);
        
        $("input", graphElem).val(graph.label);
        
        // "Add field" button
        $(".add-field-button", graphElem).click(function(e) {
            console.log('add field button');
            fieldList.append(renderField({}));
            e.preventDefault();
        });
        
        // "Remove Graph X" button
        $(".remove-single-graph-button", graphElem).click(function(e) {
            console.log('Clear graph button');
            var parentGraph = $(this).parents('.config-graph');
            parentGraph.remove();
            updateRemoveAllButton();
            e.preventDefault();
        });
                
        for (var i = 0; i < graph.fields.length; i++) {
            var 
                field = graph.fields[i],
                fieldElem = renderField(field);
            
            fieldList.append(fieldElem);
        }
        
        fieldList.on('click', 'button', function(e) {
            //alert('Fieldlist thingy');
            var
                parentGraph = $(this).parents('.config-graph');
            
            $(this).parents('.config-graph-field').remove();
            
            // TODO: This may be no longer needed, now that we can kill a whole block. In fact it may not be desirable.
            // // Remove the graph upon removal of the last field
            // if ($(".config-graph-field", parentGraph).length === 0) {
                // parentGraph.remove();
            // }           
            
            e.preventDefault();
        });
        
        // TODO: Too early?
        updateRemoveAllButton();
        
        return graphElem;
    }
    
    function renderGraphs(graphs) {
        console.log('renderGraphs');
        var
            graphList = $(".config-graphs-list", dialog);
        
        graphList.empty();
        
        for (var i = 0; i < graphs.length; i++) {
            graphList.append(renderGraph(i, graphs[i]));
        }
        // May not need?
        //updateRemoveAllButton();
    }
    
    function updateRemoveAllButton() {
        console.log('updateRemoveAllButton');
        // Show/Hide remove all button
        var graphCount = $('.config-graph').length;
        console.log('Graph count: ' + graphCount);
        if (graphCount > 0) {
            $('.config-graphs-remove-all-graphs').show();
        } else {
            $('.config-graphs-remove-all-graphs').hide();
        }
        renumberGraphIndexes();
    }
    
    function renumberGraphIndexes() {
        //debugger;
        var graphIndexes = $('.graph-index-number');
        var graphCount = graphIndexes.length;
        console.log('There are ' + graphCount + ' graphs');
        if (graphCount > 0) {
            for (var i = 0; i < graphCount; i++) {
                var currentGraphNumber = i+1;
                //debugger;
                console.log('Renumbering to ' + currentGraphNumber);
                //$(graphIndexes[i]).html(currentGraphNumber + ' (renumbered)' );
                $(graphIndexes[i]).html(currentGraphNumber);
            }
        }
    }    
    
    function populateExampleGraphs(flightLog, menu) {
        var
            i;
        
        menu.empty();
        
        exampleGraphs = GraphConfig.getExampleGraphConfigs(flightLog);
        
        exampleGraphs.unshift({
            label: "Custom graph",
            fields: [{name:""}],
            dividerAfter: true
        });
        
        for (i = 0; i < exampleGraphs.length; i++) {
            var 
                graph = exampleGraphs[i],
                li = $('<li><a href="#"></a></li>');
            
            $('a', li)
                .text(graph.label)
                .data('graphIndex', i);
            
            menu.append(li);
            
            if (graph.dividerAfter) {
                menu.append('<li class="divider"></li>');
            }
        }
    }
    
    function convertUIToGraphConfig() {
        var 
            graphs = [],
            graph,
            field;
        
        $(".config-graph", dialog).each(function() {
            graph = {
               fields: [],
               height: 1
            };
            
            graph.label = $("input[type='text']", this).val();
            
            $(".config-graph-field", this).each(function() {
                field = {
                    name: $("select", this).val()
                };
                
                if (field.name.length > 0) {
                    graph.fields.push(field);
                }
            });
            
            graphs.push(graph);
        });
        
        return graphs;
    }

    // Decide which fields we should offer to the user
    function buildOfferedFieldNamesList(flightLog, config) {
        var
            i, j,
            lastRoot = null,
            fieldNames = flightLog.getMainFieldNames(),
            fieldsSeen = {};
        
        offeredFieldNames = [];
        
        for (i = 0; i < fieldNames.length; i++) {
            // For fields with multiple bracketed x[0], x[1] versions, add an "[all]" option
            var 
                fieldName = fieldNames[i],
                matches = fieldName.match(/^(.+)\[[0-9]+\]$/);
            
            if (BLACKLISTED_FIELDS[fieldName])
                continue;
            
            if (matches) {
                if (matches[1] != lastRoot) {
                    lastRoot = matches[1];
                    
                    offeredFieldNames.push(lastRoot + "[all]");
                    fieldsSeen[lastRoot + "[all]"] = true;
                }
            } else {
                lastRoot = null;
            }
            
            offeredFieldNames.push(fieldName);
            fieldsSeen[fieldName] = true;
        }
        
        /* 
         * If the graph config has any fields in it that we don't have available in our flight log, add them to
         * the GUI anyway. (This way we can build a config when using a tricopter (which includes a tail servo) and
         * keep that tail servo in the config when we're viewing a quadcopter).
         */
        for (i = 0; i < config.length; i++) {
            var 
                graph = config[i];
            
            for (j = 0; j < graph.fields.length; j++) {
                var 
                    field = graph.fields[j];
                
                if (!fieldsSeen[field.name]) {
                    offeredFieldNames.push(field.name);
                }
            }
        }
    }
    
    this.show = function(flightLog, config) {
        dialog.modal('show');
        
        buildOfferedFieldNamesList(flightLog, config);

        populateExampleGraphs(flightLog, exampleGraphsMenu);
        renderGraphs(config);
    };
 
    $(".graph-configuration-dialog-save").click(function(e) {
        onSave(convertUIToGraphConfig());
    });
    
    $(".config-graphs-add").dropdown();
    
    var
        exampleGraphsButton = $(".config-graphs-add"),
        exampleGraphsMenu = $(".config-graphs-add ~ .dropdown-menu");
    
    exampleGraphsMenu.on("click", "a", function(e) {
        var 
            graph = exampleGraphs[$(this).data("graphIndex")],
            graphElem = renderGraph($(".config-graph", dialog).length, graph);
        
        $(".config-graphs-list", dialog).append(graphElem);
        console.log('Yes that point');
        updateRemoveAllButton();
                
        // Dismiss the dropdown button
        exampleGraphsButton.dropdown("toggle");
        
        e.preventDefault();
    });
    
    // Remove all Graphs button
    var removeAllGraphsButton = $(".config-graphs-remove-all-graphs");
    
    removeAllGraphsButton.on("click", function() {
        //alert('Remove all hit');
        $('.config-graph').remove();
        updateRemoveAllButton();
    });
    
    
}